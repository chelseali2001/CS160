# Documentation

## Dependencies

  sphinx, to install use

  ```
  pip install -U sphinx
  ```

  sphinx_rtd_theme, to install use

  ```
  pip install sphinx_rtd_theme
  ```
