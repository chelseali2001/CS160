Sensors
*******

.. toctree::
   :maxdepth: 2
   :caption: Contents:


.. currentmodule:: CozmOSU

Position
========

    .. autofunction:: calibrateLevelPitch

    .. autofunction:: getCurrentPitch

    .. autofunction:: recordPitch


Vision
======

    .. autofunction:: getVisibleCube
