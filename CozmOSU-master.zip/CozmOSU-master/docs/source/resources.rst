CozmOSU
***********
.. toctree::
   :maxdepth: 2


Python Docs
-----------

  Python 3 :  home_

  .. _home: https://docs.python.org/3/

  Data Types : types_

  .. _types: https://docs.python.org/3/library/stdtypes.html
