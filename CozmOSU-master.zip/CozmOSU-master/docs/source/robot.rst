.. toctree::
   :maxdepth: 2
   :caption: Contents:

Base Class
***********

  .. automodule:: CozmOSU

    .. autoclass:: Robot

      .. automethod:: start

      .. automethod:: getRobot

      .. automethod:: stayOnCharger

      .. automethod:: debugToggle

      .. automethod:: debug


