# CozmOSU

More complete documentation:
http://classes.engr.oregonstate.edu/eecs/fall2018/cs160-030/CozmOSU/


## Installation

From the root directory, use the one of the following commands.

Option 1:
```
pip install .
```
Option 2 (*Use this if you are developing the package*):

```
pip install -e .
```


## Usage

```
import CozmOSU as robot;
```
