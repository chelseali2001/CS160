# Drive Library

## To Do
  ### Implement
   - [ ] Drive (distance) at (rate)
   - [ ] Turn (degrees) at (degree/s)
   - [ ] Drive left wheel (rate) and right wheel (rate) - add duration to this one
   - [ ] Stop(wheels, head, lift, all)
   - [ ] Dock with cube (1,2,3)
   - [ ] Drive to position (distance) forward and (+/- distance) side to side then turn (angle)
   - [ ] Drive to world position (x) (y) at (angle)

  ### Test
   - [ ] Drive (distance) at (rate)
   - [ ] Turn (degrees) at (degree/s)
   - [ ] Drive left wheel (rate) and right wheel (rate) - add duration to this one
   - [ ] Stop(wheels, head, lift, all)
   - [ ] Dock with cube (1,2,3)
   - [ ] Drive to position (distance) forward and (+/- distance) side to side then turn (angle)
   - [ ] Drive to world position (x) (y) at (angle)